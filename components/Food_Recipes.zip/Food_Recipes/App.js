import React, { useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, View, Button, Text } from 'react-native';
import SuggestRecipesScreen from './screens/SuggestRecipesScreen';
import GetIngredientsFromRecipe from './screens/GetIngredientsFromRecipe';

export default function App() {
  const [showSuggestRecipes, setShowSuggestRecipes] = useState(true);

  const toggleScreens = () => {
    setShowSuggestRecipes((prevState) => !prevState);
  };

  return (
    <View style={styles.container}>
      <View style={styles.buttonContainer}>
        <Button
          title="Get Recipes"
          onPress={toggleScreens}
          disabled={showSuggestRecipes}
        />
        <Button
          title="Get Ingredients"
          onPress={toggleScreens}
          disabled={!showSuggestRecipes}
        />
      </View>
      <View style={styles.contentContainer}>
        {showSuggestRecipes ? <SuggestRecipesScreen /> : <GetIngredientsFromRecipe />}
      </View>
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    margin: 0,
    marginTop: 50, 
  },
  contentContainer: {
    flex: 1,
    width: '100%',
  },
});
